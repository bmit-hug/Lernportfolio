### Cluedo Daten Modell implementieren

Die Personen, Waffen und Räume erscheinen als Tabellen in der View.

(c) P. Rutschmann 2022