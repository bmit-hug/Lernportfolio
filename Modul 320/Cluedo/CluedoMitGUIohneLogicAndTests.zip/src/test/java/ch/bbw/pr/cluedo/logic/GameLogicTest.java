package ch.bbw.pr.cluedo.logic;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GameLogicTest {
   @Test
   void ActorWeaponSceneNotEqualThenReturnFalseAndHistory0() {
      assertFalse(true);
   }
}